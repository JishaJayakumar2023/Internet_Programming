function print5()
{
    alert("1");
    alert("2");
    alert("3");
    alert("4");
    alert("5");

}
print5();
print5();
